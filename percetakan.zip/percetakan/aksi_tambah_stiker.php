<?php
include 'koneksi.php';

$jenis = $_POST['jenis'];
$harga = $_POST['harga'];

mysqli_query($koneksi, "INSERT INTO stiker (jenis, harga) VALUES ('$jenis', '$harga')");
header("Location: stiker.php");
?>