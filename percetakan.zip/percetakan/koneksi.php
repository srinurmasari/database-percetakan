<?php
$koneksi = mysqli_connect("localhost", "root", "", "percetakan_");

if (!$koneksi) {
  die("Koneksi gagal: " . mysqli_connect_error());
}
?>