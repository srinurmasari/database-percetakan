<?php
include 'koneksi.php';
$data = mysqli_query($koneksi, "SELECT * FROM poster");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Data Poster</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f0f4f8;
      padding: 30px;
    }
    h2 {
      text-align: center;
      color: #2b7a78;
      margin-bottom: 20px;
    }
    .btn-tambah {
      background: #3aafa9;
      color: white;
      padding: 10px 16px;
      text-decoration: none;
      border-radius: 6px;
      margin-left: 10%;
    }
    .btn-tambah:hover {
      background: #2b7a78;
    }
    table {
      width: 80%;
      margin: auto;
      border-collapse: collapse;
      background: white;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      border-radius: 10px;
    }
    th, td {
      padding: 12px 20px;
      border-bottom: 1px solid #eee;
    }
    th {
      background: #3aafa9;
      color: white;
    }
    .aksi a {
      background: #3aafa9;
      color: white;
      padding: 6px 10px;
      margin: 0 3px;
      text-decoration: none;
      border-radius: 4px;
    }
    .aksi a:hover {
      background: #2b7a78;
    }
    .back {
      text-align: center;
      margin-top: 20px;
    }
  </style>
</head>
<body>

<h2>🖼 Data Poster</h2>
<a class="btn-tambah" href="tambah_poster_ui.php">+ Tambah Poster</a>
<table>
  <tr>
    <th>ID</th>
    <th>Ukuran</th>
    <th>Harga</th>
    <th>Aksi</th>
  </tr>
  <?php while($row = mysqli_fetch_assoc($data)) { ?>
  <tr>
    <td><?= $row['id_poster'] ?></td>
    <td><?= $row['ukuran'] ?></td>
    <td>Rp <?= number_format($row['harga']) ?></td>
    <td class="aksi">
      <a href="edit_poster_ui.php?id=<?= $row['id_poster'] ?>">Edit</a>
      <a href="hapus_poster.php?id=<?= $row['id_poster'] ?>" onclick="return confirm('Yakin mau hapus?')">Hapus</a>
    </td>
  </tr>
  <?php } ?>
</table>

<div class="back">
  <br>
  <a href="index.php">⬅ Kembali ke Dashboard</a>
</div>
</body>
</html>