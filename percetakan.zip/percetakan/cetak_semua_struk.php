<?php
include 'koneksi.php';

$tanggal = $_GET['tanggal'] ?? '';
$pelanggan = $_GET['pelanggan'] ?? '';

// fungsi ambil transaksi dan tampilkan format struk
function tampilkan_struk($query, $kategori) {
  global $koneksi;
  $result = mysqli_query($koneksi, $query);
  while ($row = mysqli_fetch_assoc($result)) {
    echo "<pre style='font-family: monospace'>";
    echo "Cetakan Digital Andalan\n";
    echo "-------------------------------\n";
    echo "Kategori       : $kategori\n";
    echo "Nama Pelanggan : {$row['nama']}\n";
    echo "Tanggal        : " . date('d-m-Y', strtotime($row['tanggal'])) . "\n";
    echo "Produk         : {$row['produk']}\n";
    echo "Jumlah         : {$row['jumlah_pesanan']}\n";
    echo "Harga Satuan   : Rp " . number_format($row['harga_satuan']) . "\n";
    echo "Total Harga    : Rp " . number_format($row['total_harga']) . "\n";
    echo "-------------------------------\n\n";
    echo "</pre>";
  }
}

// Filter query
$where_tgl = $tanggal ? "AND ts.tanggal = '$tanggal'" : "";
$where_pel = $pelanggan ? "AND p.nama LIKE '%$pelanggan%'" : "";

// Struk stiker
tampilkan_struk("
  SELECT ts.tanggal, p.nama, s.jenis AS produk, ts.jumlah_pesanan, s.harga AS harga_satuan, ts.total_harga
  FROM transaksi_stiker ts
  JOIN pelanggan p ON ts.id_pelanggan = p.id_pelanggan
  JOIN stiker s ON ts.id_stiker = s.id_stiker
  WHERE 1=1 $where_tgl $where_pel
", "Stiker");

// Struk poster
tampilkan_struk("
  SELECT tp.tanggal, p.nama, po.ukuran AS produk, tp.jumlah_pesanan, po.harga AS harga_satuan, tp.total_harga
  FROM transaksi_poster tp
  JOIN pelanggan p ON tp.id_pelanggan = p.id_pelanggan
  JOIN poster po ON tp.id_poster = po.id_poster
  WHERE 1=1 $where_tgl $where_pel
", "Poster");

// Struk spanduk
tampilkan_struk("
  SELECT ts.tanggal, p.nama, CONCAT(s.jenis, ' ', s.ukuran) AS produk, ts.jumlah_pesanan, s.harga AS harga_satuan, ts.total_harga
  FROM transaksi_spanduk ts
  JOIN pelanggan p ON ts.id_pelanggan = p.id_pelanggan
  JOIN spanduk s ON ts.id_spanduk = s.id_spanduk
  WHERE 1=1 $where_tgl $where_pel
", "Spanduk");
?>

<script>
  window.print();
</script>