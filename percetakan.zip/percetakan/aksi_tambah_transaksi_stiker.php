<?php
include 'koneksi.php';

$id_pelanggan = $_POST['id_pelanggan'];
$id_stiker = $_POST['id_stiker'];
$jumlah = $_POST['jumlah_pesanan'];
$total = $_POST['total_harga'];
$tanggal = date('Y-m-d');

mysqli_query($koneksi, "INSERT INTO transaksi_stiker (id_pelanggan, tanggal, id_stiker, jumlah_pesanan, total_harga)
VALUES ('$id_pelanggan', '$tanggal', '$id_stiker', '$jumlah', '$total')");

header("Location: transaksi_stiker.php");
?>