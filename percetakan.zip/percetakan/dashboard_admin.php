<?php
include 'koneksi.php';

// Total pelanggan
$pelanggan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM pelanggan"))['total'];

// Total transaksi per layanan
$trans_stiker = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM transaksi_stiker"))['total'];
$trans_poster = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM transaksi_poster"))['total'];
$trans_spanduk = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM transaksi_spanduk"))['total'];

// Total pendapatan
$total1 = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(total_harga) AS total FROM transaksi_stiker"))['total'] ?? 0;
$total2 = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(total_harga) AS total FROM transaksi_poster"))['total'] ?? 0;
$total3 = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(total_harga) AS total FROM transaksi_spanduk"))['total'] ?? 0;
$total_pendapatan = $total1 + $total2 + $total3;
?>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard Admin</title>
  <style>
    body {
      font-family: 'Segoe UI'; background: #f4f8fb; padding: 40px;
    }
    h1 {
      text-align: center; color: #2b7a78;
    }
    .card-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-top: 30px;
    }
    .card {
      background: white; border-radius: 10px; padding: 25px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center;
    }
    .card h3 {
      margin-bottom: 10px; color: #3aafa9;
    }
    .card p {
      font-size: 24px; font-weight: bold; color: #333;
    }
    .footer {
      text-align: center; margin-top: 40px; color: #777;
    }
    .emoji {
      font-size: 30px; margin-bottom: 10px;
    }
  </style>
</head>
<body>
  <h1>📊 Dashboard Admin Percetakan</h1>
  <div class="card-container">
    <div class="card">
      <div class="emoji">👥</div>
      <h3>Total Pelanggan</h3>
      <p><?= $pelanggan ?></p>
    </div>
    <div class="card">
      <div class="emoji">🎨</div>
      <h3>Transaksi Stiker</h3>
      <p><?= $trans_stiker ?></p>
    </div>
    <div class="card">
      <div class="emoji">🖼</div>
      <h3>Transaksi Poster</h3>
      <p><?= $trans_poster ?></p>
    </div>
    <div class="card">
      <div class="emoji">🧵</div>
      <h3>Transaksi Spanduk</h3>
      <p><?= $trans_spanduk ?></p>
    </div>
    <div class="card">
      <div class="emoji">💰</div>
      <h3>Total Pendapatan</h3>
      <p>Rp <?= number_format($total_pendapatan) ?></p>
    </div>
  </div>

  <div class="footer">
    Terakhir diperbarui: <?= date('d-m-Y H:i') ?>
  </div>
</body>
</html>