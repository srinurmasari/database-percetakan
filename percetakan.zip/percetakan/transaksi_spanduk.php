<?php
include 'koneksi.php';
$data = mysqli_query($koneksi, "
  SELECT ts.*, p.nama, s.jenis, s.ukuran 
  FROM transaksi_spanduk ts
  JOIN pelanggan p ON ts.id_pelanggan = p.id_pelanggan
  JOIN spanduk s ON ts.id_spanduk = s.id_spanduk
");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Transaksi Spanduk</title>
  <style>
    body { font-family: 'Segoe UI'; background: #f0f4f8; padding: 30px; }
    h2 { text-align: center; color: #2b7a78; }
    .btn { background: #3aafa9; color: white; padding: 10px 16px; text-decoration: none; border-radius: 6px; display: inline-block; margin-bottom: 20px; }
    .btn:hover { background: #2b7a78; }
    table { width: 100%; border-collapse: collapse; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    th, td { padding: 12px 20px; border-bottom: 1px solid #eee; text-align: center; }
    th { background: #3aafa9; color: white; }
    .aksi a { background: #3aafa9; color: white; padding: 6px 10px; margin: 0 3px; text-decoration: none; border-radius: 4px; }
    .aksi a:hover { background: #2b7a78; }
  </style>
</head>
<body>
<h2>🧵 Transaksi Spanduk</h2>
<a class="btn" href="tambah_transaksi_spanduk_ui.php">+ Tambah Transaksi</a>
<table>
  <tr>
    <th>No</th><th>Tanggal</th><th>Pelanggan</th><th>Jenis</th><th>Ukuran</th><th>Jumlah</th><th>Total Harga</th><th>Aksi</th>
  </tr>
  <?php $no = 1; while($row = mysqli_fetch_assoc($data)) { ?>
  <tr>
    <td><?= $no++ ?></td>
    <td><?= $row['tanggal'] ?></td>
    <td><?= $row['nama'] ?></td>
    <td><?= $row['jenis'] ?></td>
    <td><?= $row['ukuran'] ?></td>
    <td><?= $row['jumlah_pesanan'] ?></td>
    <td>Rp <?= number_format($row['total_harga']) ?></td>
    <td class="aksi">
      <a href="edit_transaksi_spanduk_ui.php?id=<?= $row['id_transaksi'] ?>">Edit</a>
      <a href="hapus_transaksi_spanduk.php?id=<?= $row['id_transaksi'] ?>" onclick="return confirm('Yakin ingin hapus?')">Hapus</a>
    </td>
  </tr>
  <?php } ?>
</table>
</body>
</html>