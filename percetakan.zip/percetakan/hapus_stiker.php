<?php
include 'koneksi.php';
$id = $_GET['id'];

mysqli_query($koneksi, "DELETE FROM stiker WHERE id_stiker=$id");
header("Location: stiker.php");
?>