<?php
include 'koneksi.php';

// Ambil data filter
$tanggal = $_GET['tanggal'] ?? '';
$pelanggan = $_GET['pelanggan'] ?? '';

$where_stiker = $where_poster = $where_spanduk = "";
if ($tanggal) {
  $where_stiker .= " AND ts.tanggal = '$tanggal'";
  $where_poster .= " AND tp.tanggal = '$tanggal'";
  $where_spanduk .= " AND ts.tanggal = '$tanggal'";
}
if ($pelanggan) {
  $where_stiker .= " AND p.nama LIKE '%$pelanggan%'";
  $where_poster .= " AND p.nama LIKE '%$pelanggan%'";
  $where_spanduk .= " AND p.nama LIKE '%$pelanggan%'";
}

// Query
$stiker = mysqli_query($koneksi, "
  SELECT ts.tanggal, p.nama AS pelanggan, s.jenis AS produk, ts.jumlah_pesanan, ts.total_harga, 'Stiker' AS kategori
  FROM transaksi_stiker ts
  JOIN pelanggan p ON ts.id_pelanggan = p.id_pelanggan
  JOIN stiker s ON ts.id_stiker = s.id_stiker
  WHERE 1=1 $where_stiker
");

$poster = mysqli_query($koneksi, "
  SELECT tp.tanggal, p.nama AS pelanggan, po.ukuran AS produk, tp.jumlah_pesanan, tp.total_harga, 'Poster' AS kategori
  FROM transaksi_poster tp
  JOIN pelanggan p ON tp.id_pelanggan = p.id_pelanggan
  JOIN poster po ON tp.id_poster = po.id_poster
  WHERE 1=1 $where_poster
");

$spanduk = mysqli_query($koneksi, "
  SELECT ts.tanggal, p.nama AS pelanggan, CONCAT(s.jenis, ' ', s.ukuran) AS produk, ts.jumlah_pesanan, ts.total_harga, 'Spanduk' AS kategori
  FROM transaksi_spanduk ts
  JOIN pelanggan p ON ts.id_pelanggan = p.id_pelanggan
  JOIN spanduk s ON ts.id_spanduk = s.id_spanduk
  WHERE 1=1 $where_spanduk
");

$laporan = [];
while ($row = mysqli_fetch_assoc($stiker)) $laporan[] = $row;
while ($row = mysqli_fetch_assoc($poster)) $laporan[] = $row;
while ($row = mysqli_fetch_assoc($spanduk)) $laporan[] = $row;

usort($laporan, fn($a, $b) => strtotime($a['tanggal']) - strtotime($b['tanggal']));
?>

<!DOCTYPE html>
<html>
<head>
  <title>Laporan Transaksi</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f8fb;
      padding: 40px;
    }
    h2 {
      color: #2b7a78;
    }
    form input, form button, form a {
      margin: 5px;
      padding: 6px 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    form button {
      background: #3aafa9;
      color: white;
      border: none;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 25px;
    }
    th, td {
      padding: 10px;
      border: 1px solid #ddd;
    }
    th {
      background: #def2f1;
    }
    tr:nth-child(even) {
      background: #f9f9f9;
    }
  </style>
</head>
<body>

<h2>📑 Laporan Transaksi</h2>

<form method="GET">
  Filter Tanggal:
  <input type="date" name="tanggal" value="<?= $tanggal ?>">
  Nama Pelanggan:
  <input type="text" name="pelanggan" value="<?= $pelanggan ?>">
  <button type="submit">Tampilkan</button>
  <a href="laporan_transaksi_ui.php">Reset</a>
  <a href="cetak_semua_struk.php?tanggal=<?= $tanggal ?>&pelanggan=<?= $pelanggan ?>" target="_blank">🖨 Cetak Semua Struk</a>
</form>

<table>
  <tr>
    <th>No</th>
    <th>Tanggal</th>
    <th>Nama Pelanggan</th>
    <th>Kategori</th>
    <th>Produk</th>
    <th>Jumlah</th>
    <th>Total Harga</th>
  </tr>

  <?php $no = 1; foreach ($laporan as $row): ?>
  <tr>
    <td><?= $no++ ?></td>
    <td><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
    <td><?= $row['pelanggan'] ?></td>
    <td><?= $row['kategori'] ?></td>
    <td><?= $row['produk'] ?></td>
    <td><?= $row['jumlah_pesanan'] ?></td>
    <td>Rp <?= number_format($row['total_harga']) ?></td>
  </tr>
  <?php endforeach; ?>
</table>

</body>
</html>