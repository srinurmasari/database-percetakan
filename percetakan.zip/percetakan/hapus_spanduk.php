<?php
include 'koneksi.php';
$id = $_GET['id'];

mysqli_query($koneksi, "DELETE FROM spanduk WHERE id_spanduk=$id");
header("Location: spanduk.php");
?>