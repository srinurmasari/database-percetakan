<?php
include 'koneksi.php';

$id = $_POST['id'];
$jenis = $_POST['jenis'];
$harga = $_POST['harga'];

mysqli_query($koneksi, "UPDATE stiker SET jenis='$jenis', harga='$harga' WHERE id_stiker=$id");
header("Location: stiker.php");
?>