<?php
include 'koneksi.php';
$id = $_GET['id'];

mysqli_query($koneksi, "DELETE FROM poster WHERE id_poster=$id");
header("Location: poster.php");
?>