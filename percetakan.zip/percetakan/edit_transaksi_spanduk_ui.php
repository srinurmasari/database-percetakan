<?php
include 'koneksi.php';
$id = $_GET['id'];
$tr = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM transaksi_spanduk WHERE id_transaksi=$id"));
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Transaksi Spanduk</title>
  <style>
    body { font-family: 'Segoe UI'; background: #f0f4f8; padding: 30px; }
    .form-container { background: white; padding: 30px; max-width: 600px; margin: auto; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    h2 { text-align: center; color: #2b7a78; }
    label { display: block; margin-top: 15px; font-weight: bold; }
    select, input[type="number"], input[type="date"] {
      width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 6px;
    }
    button {
      margin-top: 25px; padding: 10px 20px; background: #3aafa9;
      color: white; border: none; border-radius: 6px; font-size: 16px; cursor: pointer;
    }
    button:hover { background: #2b7a78; }
  </style>
</head>
<body>
<div class="form-container">
  <h2>✏ Edit Transaksi Spanduk</h2>
  <form method="POST">
    <label>Pelanggan:</label>
    <select name="id_pelanggan">
      <?php
      $pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan");
      while ($p = mysqli_fetch_assoc($pelanggan)) {
        $selected = ($p['id_pelanggan'] == $tr['id_pelanggan']) ? 'selected' : '';
        echo "<option value='{$p['id_pelanggan']}' $selected>{$p['nama']}</option>";
      }
      ?>
    </select>

    <label>Spanduk:</label>
    <select name="id_spanduk">
      <?php
      $spanduk = mysqli_query($koneksi, "SELECT * FROM spanduk");
      while ($s = mysqli_fetch_assoc($spanduk)) {
        $selected = ($s['id_spanduk'] == $tr['id_spanduk']) ? 'selected' : '';
        echo "<option value='{$s['id_spanduk']}' $selected>{$s['jenis']} - {$s['ukuran']}</option>";
      }
      ?>
    </select>

    <label>Jumlah:</label>
    <input type="number" name="jumlah" value="<?= $tr['jumlah_pesanan'] ?>" required>

    <label>Tanggal:</label>
    <input type="date" name="tanggal" value="<?= $tr['tanggal'] ?>" required>

    <button type="submit">Simpan Perubahan</button>
  </form>
</div>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $id_pelanggan = $_POST['id_pelanggan'];
  $id_spanduk = $_POST['id_spanduk'];
  $jumlah = $_POST['jumlah'];
  $tanggal = $_POST['tanggal'];
  $get = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT harga FROM spanduk WHERE id_spanduk=$id_spanduk"));
  $total = $jumlah * $get['harga'];
  mysqli_query($koneksi, "UPDATE transaksi_spanduk SET id_pelanggan=$id_pelanggan, id_spanduk=$id_spanduk, jumlah_pesanan=$jumlah, tanggal='$tanggal', total_harga=$total WHERE id_transaksi=$id");
  header("Location: transaksi_spanduk_ui.php");
}
?>