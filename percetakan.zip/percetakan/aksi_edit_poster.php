<?php
include 'koneksi.php';

$id = $_POST['id'];
$ukuran = $_POST['ukuran'];
$harga = $_POST['harga'];

mysqli_query($koneksi, "UPDATE poster SET ukuran='$ukuran', harga='$harga' WHERE id_poster=$id");
header("Location: poster.php");
?>