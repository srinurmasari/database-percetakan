<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <title>Tambah Stiker</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f0f4f8;
      padding: 40px;
    }
    .form-container {
      background: white;
      padding: 30px;
      max-width: 500px;
      margin: auto;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      color: #2b7a78;
      margin-bottom: 20px;
    }
    label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
    }
    input[type="text"], input[type="number"] {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    button {
      margin-top: 25px;
      padding: 10px 20px;
      background: #3aafa9;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }
    button:hover {
      background: #2b7a78;
    }
    .back {
      text-align: center;
      margin-top: 15px;
    }
    .back a {
      color: #333;
      text-decoration: none;
    }
  </style>
</head>
<body>
<div class="form-container">
  <h2>➕ Tambah Stiker</h2>
  <form method="POST">
    <label>Jenis Stiker:</label>
    <input type="text" name="jenis" required>

    <label>Harga:</label>
    <input type="number" name="harga" required>

    <button type="submit">Simpan</button>
  </form>
  <div class="back">
    <br>
    <a href="stiker_ui.php">⬅ Kembali</a>
  </div>
</div>
</body>
</html>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $jenis = $_POST['jenis'];
  $harga = $_POST['harga'];
  mysqli_query($koneksi, "INSERT INTO stiker (jenis, harga) VALUES ('$jenis', '$harga')");
  header("Location: stiker_ui.php");
}
?>
