<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Percetakan</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f0f4f8;
      margin: 0;
      padding: 0;
    }

    header {
      background: #2b7a78;
      color: white;
      padding: 20px;
      text-align: center;
    }

    h1 {
      margin: 0;
    }

    .container {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      padding: 30px;
      gap: 20px;
    }

    .card {
      background: white;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      width: 250px;
      text-align: center;
      padding: 25px;
      text-decoration: none;
      color: #333;
      transition: 0.2s ease;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.15);
      background: #def2f1;
    }

    .card h3 {
      margin: 0;
      margin-bottom: 10px;
      color: #3aafa9;
    }

    .footer {
      text-align: center;
      padding: 10px;
      font-size: 13px;
      color: #888;
    }
  </style>
</head>
<body>

  <header>
    <h1>Selamat Datang di Dashboard Percetakan</h1>
    <p>Kelola pelanggan, layanan, dan transaksi dengan mudah 💻</p>
  </header>

  <div class="container">
    <a href="pelanggan.php" class="card">
      <h3>📇 Pelanggan</h3>
      <p>Tambah & edit data pelanggan</p>
    </a>
    <a href="stiker.php" class="card">
      <h3>🖨 Layanan Stiker</h3>
      <p>Lihat & atur jenis stiker</p>
    </a>
    <a href="poster.php" class="card">
      <h3>🖼 Layanan Poster</h3>
      <p>Data ukuran & harga poster</p>
    </a>
    <a href="spanduk.php" class="card">
      <h3>📢 Layanan Spanduk</h3>
      <p>Jenis & ukuran spanduk</p>
    </a>
    <a href="transaksi_stiker.php" class="card">
      <h3>💰 Transaksi Stiker</h3>
      <p>Cek & input semua transaksi</p>
    </a>
    <a href="transaksi_poster.php" class="card">
      <h3>💰 Transaksi Poster</h3>
      <p>Cek & input semua transaksi</p>
    </a>
    <a href="transaksi_spanduk.php" class="card">
      <h3>💰 Transaksi Spanduk</h3>
      <p>Cek & input semua transaksi</p>
    </a>
    <a href="laporan_transaksi.php" class="card">
      <h3>📊 Laporan</h3>
      <p>Rekap dan filter transaksi</p>
    </a>
  </div>

  <div class="footer">
    &copy; <?= date("Y") ?> Percetakan Sederhana | Dibuat dengan 💙 oleh Kamu
  </div>

</body>
</html>