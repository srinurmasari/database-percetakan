<?php
include 'koneksi.php';

$id = $_POST['id'];
$jenis = $_POST['jenis'];
$ukuran = $_POST['ukuran'];
$harga = $_POST['harga'];

mysqli_query($koneksi, "UPDATE spanduk SET jenis='$jenis', ukuran='$ukuran', harga='$harga' WHERE id_spanduk=$id");
header("Location: spanduk.php");
?>