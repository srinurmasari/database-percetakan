<?php
include 'koneksi.php';

$id_transaksi = $_POST['id_transaksi'];
$id_pelanggan = $_POST['id_pelanggan'];
$id_stiker = $_POST['id_stiker'];
$jumlah = $_POST['jumlah_pesanan'];
$total = $_POST['total_harga'];

mysqli_query($koneksi, "
  UPDATE transaksi_stiker SET 
  id_pelanggan='$id_pelanggan', 
  id_stiker='$id_stiker',
  jumlah_pesanan='$jumlah',
  total_harga='$total'
  WHERE id_transaksi='$id_transaksi'
");

header("Location: transaksi_stiker.php");
?>