<?php
include 'koneksi.php';

$id = $_POST['id_transaksi'];
$id_pelanggan = $_POST['id_pelanggan'];
$id_spanduk = $_POST['id_spanduk'];
$jumlah = $_POST['jumlah_pesanan'];
$total = $_POST['total_harga'];

mysqli_query($koneksi, "
  UPDATE transaksi_spanduk SET 
  id_pelanggan = '$id_pelanggan',
  id_spanduk = '$id_spanduk',
  jumlah_pesanan = '$jumlah',
  total_harga = '$total'
  WHERE id_transaksi = '$id'
");

header("Location: transaksi_spanduk.php");
?>