<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <title>Tambah Transaksi Stiker</title>
  <style>
    body { font-family: 'Segoe UI'; background: #f0f4f8; padding: 30px; }
    .form-container { background: white; padding: 30px; max-width: 600px; margin: auto; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    h2 { text-align: center; color: #2b7a78; }
    label { display: block; margin-top: 15px; font-weight: bold; }
    select, input[type="number"], input[type="date"] {
      width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 6px;
    }
    button {
      margin-top: 25px; padding: 10px 20px; background: #3aafa9;
      color: white; border: none; border-radius: 6px; font-size: 16px; cursor: pointer;
    }
    button:hover { background: #2b7a78; }
  </style>
</head>
<body>
<div class="form-container">
  <h2>🎨 Tambah Transaksi Stiker</h2>
  <form method="POST">
    <label>Pelanggan:</label>
    <select name="id_pelanggan">
      <?php
      $pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan");
      while ($p = mysqli_fetch_assoc($pelanggan)) {
        echo "<option value='{$p['id_pelanggan']}'>{$p['nama']}</option>";
      }
      ?>
    </select>

    <label>Jenis Stiker:</label>
    <select name="id_stiker">
      <?php
      $stiker = mysqli_query($koneksi, "SELECT * FROM stiker");
      while ($s = mysqli_fetch_assoc($stiker)) {
        echo "<option value='{$s['id_stiker']}'>{$s['jenis']}</option>";
      }
      ?>
    </select>

    <label>Jumlah:</label>
    <input type="number" name="jumlah" required>

    <label>Tanggal:</label>
    <input type="date" name="tanggal" required>

    <button type="submit">Simpan Transaksi</button>
  </form>
</div>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $id_pelanggan = $_POST['id_pelanggan'];
  $id_stiker = $_POST['id_stiker'];
  $jumlah = $_POST['jumlah'];
  $tanggal = $_POST['tanggal'];
  $get = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT harga FROM stiker WHERE id_stiker=$id_stiker"));
  $total = $jumlah * $get['harga'];
  mysqli_query($koneksi, "INSERT INTO transaksi_stiker (id_pelanggan, id_stiker, jumlah_pesanan, tanggal, total_harga) VALUES ($id_pelanggan, $id_stiker, $jumlah, '$tanggal', $total)");
  header("Location: transaksi_stiker_ui.php");
}
?>