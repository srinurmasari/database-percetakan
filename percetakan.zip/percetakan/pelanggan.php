<?php
include 'koneksi.php';
$data = mysqli_query($koneksi, "SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Data Pelanggan</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f0f4f8;
      padding: 30px;
    }

    h2 {
      text-align: center;
      color: #2b7a78;
      margin-bottom: 30px;
    }

    .btn-tambah {
      display: inline-block;
      background: #3aafa9;
      color: white;
      padding: 10px 16px;
      border-radius: 6px;
      text-decoration: none;
      margin-bottom: 20px;
      margin-left: 10%;
    }

    .btn-tambah:hover {
      background: #2b7a78;
    }

    table {
      width: 80%;
      margin: auto;
      border-collapse: collapse;
      background: white;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      border-radius: 10px;
      overflow: hidden;
    }

    th, td {
      padding: 12px 20px;
      border-bottom: 1px solid #eee;
      text-align: left;
    }

    th {
      background: #3aafa9;
      color: white;
    }

    tr:hover {
      background: #f1fdfd;
    }

    .aksi a {
      background: #3aafa9;
      color: white;
      padding: 6px 10px;
      margin: 0 3px;
      text-decoration: none;
      border-radius: 4px;
      font-size: 14px;
    }

    .aksi a:hover {
      background: #2b7a78;
    }

    .back {
      text-align: center;
      margin-top: 20px;
    }

    .back a {
      text-decoration: none;
      color: #333;
      font-size: 14px;
    }
  </style>
</head>
<body>

  <h2>📋 Data Pelanggan</h2>
  <a class="btn-tambah" href="tambah_pelanggan.php">+ Tambah Pelanggan</a>

  <table>
    <tr>
      <th>ID</th>
      <th>Nama</th>
      <th>No HP</th>
      <th>Alamat</th>
      <th>Aksi</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($data)) { ?>
    <tr>
      <td><?= $row['id_pelanggan'] ?></td>
      <td><?= $row['nama'] ?></td>
      <td><?= $row['no_hp'] ?></td>
      <td><?= $row['alamat'] ?></td>
      <td class="aksi">
        <a href="edit_pelanggan.php?id=<?= $row['id_pelanggan'] ?>">Edit</a>
        <a href="hapus_pelanggan.php?id=<?= $row['id_pelanggan'] ?>" onclick="return confirm('Yakin mau hapus?')">Hapus</a>
      </td>
    </tr>
    <?php } ?>
  </table>

  <div class="back">
    <br>
    <a href="index.php">⬅ Kembali ke Dashboard</a>
  </div>

</body>
</html>