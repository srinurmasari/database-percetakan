<?php
include 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM spanduk WHERE id_spanduk=$id");
$row = mysqli_fetch_assoc($data);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Spanduk</title>
  <style>
    body { font-family: 'Segoe UI'; background: #f0f4f8; padding: 40px; }
    .form-container { background: white; padding: 30px; max-width: 500px; margin: auto; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    label { display: block; margin-top: 15px; font-weight: bold; }
    input[type="text"], input[type="number"] { width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 6px; }
    button { margin-top: 25px; padding: 10px 20px; background: #3aafa9; color: white; border: none; border-radius: 6px; font-size: 16px; cursor: pointer; }
    button:hover { background: #2b7a78; }
  </style>
</head>
<body>
<div class="form-container">
  <h2>✏ Edit Spanduk</h2>
  <form method="POST">
    <label>Jenis:</label>
    <input type="text" name="jenis" value="<?= $row['jenis'] ?>" required>

    <label>Ukuran:</label>
    <input type="text" name="ukuran" value="<?= $row['ukuran'] ?>" required>

    <label>Harga:</label>
    <input type="number" name="harga" value="<?= $row['harga'] ?>" required>

    <button type="submit">Simpan Perubahan</button>
  </form>
</div>
</body>
</html>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $jenis = $_POST['jenis'];
  $ukuran = $_POST['ukuran'];
  $harga = $_POST['harga'];
  mysqli_query($koneksi, "UPDATE spanduk SET jenis='$jenis', ukuran='$ukuran', harga='$harga' WHERE id_spanduk=$id");
  header("Location: spanduk_ui.php");
}
?>