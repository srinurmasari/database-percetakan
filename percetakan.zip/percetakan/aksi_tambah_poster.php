<?php
include 'koneksi.php';

$ukuran = $_POST['ukuran'];
$harga = $_POST['harga'];

mysqli_query($koneksi, "INSERT INTO poster (ukuran, harga) VALUES ('$ukuran', '$harga')");
header("Location: poster.php");
?>