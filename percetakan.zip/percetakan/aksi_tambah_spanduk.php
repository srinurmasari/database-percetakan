<?php
include 'koneksi.php';

$jenis = $_POST['jenis'];
$ukuran = $_POST['ukuran'];
$harga = $_POST['harga'];

mysqli_query($koneksi, "INSERT INTO spanduk (jenis, ukuran, harga) VALUES ('$jenis', '$ukuran', '$harga')");
header("Location: spanduk.php");
?>