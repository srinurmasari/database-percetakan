<?php
include 'koneksi.php';

$id_pelanggan = $_POST['id_pelanggan'];
$id_spanduk = $_POST['id_spanduk'];
$jumlah = $_POST['jumlah_pesanan'];
$total = $_POST['total_harga'];
$tanggal = date('Y-m-d');

mysqli_query($koneksi, "INSERT INTO transaksi_spanduk 
(id_pelanggan, tanggal, id_spanduk, jumlah_pesanan, total_harga)
VALUES ('$id_pelanggan', '$tanggal', '$id_spanduk', '$jumlah', '$total')");

header("Location: transaksi_spanduk.php");
?>