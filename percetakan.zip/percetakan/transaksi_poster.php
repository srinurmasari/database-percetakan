<?php
include 'koneksi.php';
$data = mysqli_query($koneksi, "
  SELECT tp.*, p.nama, po.ukuran 
  FROM transaksi_poster tp
  JOIN pelanggan p ON tp.id_pelanggan = p.id_pelanggan
  JOIN poster po ON tp.id_poster = po.id_poster
");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Transaksi Poster</title>
  <style>
    body { font-family: 'Segoe UI'; background: #f0f4f8; padding: 30px; }
    h2 { text-align: center; color: #2b7a78; }
    .btn { background: #3aafa9; color: white; padding: 10px 16px; text-decoration: none; border-radius: 6px; margin-left: 10%; }
    .btn:hover { background: #2b7a78; }
    table { width: 80%; margin: auto; border-collapse: collapse; background: white; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    th, td { padding: 12px 20px; border-bottom: 1px solid #eee; text-align: center; }
    th { background: #3aafa9; color: white; }
    .aksi a { background: #3aafa9; color: white; padding: 6px 10px; margin: 0 3px; text-decoration: none; border-radius: 4px; }
    .aksi a:hover { background: #2b7a78; }
  </style>
</head>
<body>
<h2>🖼 Transaksi Poster</h2>
<a class="btn" href="tambah_transaksi_poster_ui.php">+ Tambah Transaksi</a>
<table>
  <tr>
    <th>No</th><th>Tanggal</th><th>Pelanggan</th><th>Ukuran</th><th>Jumlah</th><th>Total Harga</th><th>Aksi</th>
  </tr>
  <?php $no = 1; while($row = mysqli_fetch_assoc($data)) { ?>
  <tr>
    <td><?= $no++ ?></td>
    <td><?= $row['tanggal'] ?></td>
    <td><?= $row['nama'] ?></td>
    <td><?= $row['ukuran'] ?></td>
    <td><?= $row['jumlah_pesanan'] ?></td>
    <td>Rp <?= number_format($row['total_harga']) ?></td>
    <td class="aksi">
      <a href="edit_transaksi_poster_ui.php?id=<?= $row['id_transaksi'] ?>">Edit</a>
      <a href="hapus_transaksi_poster.php?id=<?= $row['id_transaksi'] ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
    </td>
  </tr>
  <?php } ?>
</table>
</body>
</html>